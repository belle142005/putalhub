<?php
// PetalHub backend for XAMPP (PHP + MySQL). Same API the website always used: /api/products, /api/login, /api/orders ...
// Written to run on PHP 7.2 or newer (XAMPP).
require __DIR__ . '/config.php';
date_default_timezone_set(PH_TIMEZONE);
ini_set('display_errors', '0');
header('Content-Type: application/json; charset=utf-8');
header('X-Content-Type-Options: nosniff');
header('Cache-Control: no-store');

class ApiError extends Exception {}
function fail($code, $msg){ throw new ApiError($msg, $code); }
function send($code, $obj){ http_response_code($code); echo json_encode($obj, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES); exit; }
function emptyObj(){ return new stdClass(); }

/* ---------- database ---------- */
function db(){
  static $pdo = null;
  if ($pdo) return $pdo;
  try {
    $pdo = new PDO('mysql:host=' . DB_HOST . ';port=' . DB_PORT . ';dbname=' . DB_NAME . ';charset=utf8mb4', DB_USER, DB_PASS, array(
      PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION, PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC, PDO::ATTR_EMULATE_PREPARES => false));
  } catch (PDOException $e) {
    error_log('PetalHub DB connect: ' . $e->getMessage());
    $driverCode = isset($e->errorInfo[1]) ? (int)$e->errorInfo[1] : 0;
    if ($driverCode === 1045) fail(500, 'MySQL rejected the configured credentials. Check DB_HOST, DB_PORT, DB_USER and DB_PASS in config.php.');
    if ($driverCode === 1049) fail(500, 'The petalhub database does not exist. Import schema.sql in phpMyAdmin, then check config.php.');
    fail(500, 'Cannot connect to the MySQL database. In XAMPP start MySQL, import schema.sql in phpMyAdmin, and check config.php.');
  }
  $pdo->exec("SET time_zone = '" . date('P') . "'"); // keep MySQL NOW() and PHP on the same clock
  return $pdo;
}
function q($sql, $args = array()){ $st = db()->prepare($sql); $st->execute($args); return $st; }
function rows($sql, $args = array()){ return q($sql, $args)->fetchAll(); }
function row($sql, $args = array()){ $r = q($sql, $args)->fetch(); return $r ? $r : null; }
function marks($n){ return implode(',', array_fill(0, $n, '?')); }

/* ---------- small helpers ---------- */
function body(){
  $raw = file_get_contents('php://input');
  if (strlen($raw) > 100000) fail(413, 'Request too large.');
  if ($raw === '' || $raw === false) return array();
  $j = json_decode($raw, true);
  if (!is_array($j)) fail(400, 'Invalid JSON.');
  return $j;
}
function cut($s, $n){ return function_exists('mb_substr') ? mb_substr($s, 0, $n, 'UTF-8') : substr($s, 0, $n); }
function lower($s){ return function_exists('mb_strtolower') ? mb_strtolower($s, 'UTF-8') : strtolower($s); }
function str($v, $n){ return is_string($v) ? cut(trim($v), $n) : ''; }
function isInt($v){ return is_int($v) || (is_float($v) && floor($v) == $v); }
function isNum($v){ return is_int($v) || is_float($v); }
function get($a, $k, $d = null){ return is_array($a) && array_key_exists($k, $a) ? $a[$k] : $d; }
function iso($dt){ return gmdate('Y-m-d\TH:i:s', strtotime($dt)) . '.000Z'; }

/* ---------- passwords ---------- */
// New hashes are PBKDF2 ("p2:..."). Accounts made by the old Node version used scrypt; those still work when PHP's sodium
// extension is available, and are upgraded to PBKDF2 the first time the person logs in.
function hashPw($pw, $salt){ return 'p2:' . hash_pbkdf2('sha256', $pw, $salt, 120000, 64, false); }
function checkHash($stored, $pw, $salt){
  if ($stored === null || $stored === '') return false;
  if (substr($stored, 0, 3) === 'p2:') return hash_equals($stored, hashPw($pw, $salt));
  if (function_exists('sodium_crypto_pwhash_scryptsalsa208sha256') && strlen($salt) === 32){
    try { return hash_equals($stored, bin2hex(sodium_crypto_pwhash_scryptsalsa208sha256(64, $pw, $salt, 524288, 16777216))); } catch (Exception $e) { return false; }
  }
  return false;
}
function newSalt(){ return bin2hex(random_bytes(16)); }
function addUser($name, $email, $pw, $role, $question = null, $answer = null){
  $salt = newSalt(); $ss = $answer ? newSalt() : null;
  q('INSERT INTO users (name, email, salt, password_hash, role, security_question, security_salt, security_hash) VALUES (?,?,?,?,?,?,?,?)',
    array($name, $email, $salt, hashPw($pw, $salt), $role, $answer ? $question : null, $ss, $answer ? hashPw(lower(trim($answer)), $ss) : null));
  return (int)db()->lastInsertId();
}

/* ---------- first-run setup (adds missing columns, creates the admin account) ---------- */
function ensureSetup(){
  // an admin made by the old Node version can only be read when PHP has the sodium extension; otherwise reset it to config.php's password
  if (!function_exists('sodium_crypto_pwhash_scryptsalsa208sha256')){ $sl = newSalt(); q("UPDATE users SET salt = ?, password_hash = ? WHERE role = 'admin' AND password_hash NOT LIKE 'p2:%'", array($sl, hashPw(ADMIN_PASSWORD, $sl))); }
  $check = "SELECT (SELECT COUNT(*) FROM users WHERE role = 'admin') AS a,
                   (SELECT COUNT(*) FROM information_schema.STATISTICS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'orders' AND INDEX_NAME = 'uq_orders_user_key') AS k,
                   (SELECT COUNT(*) FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'order_items' AND COLUMN_NAME IN ('line_key','line_name','arrangement','line_qty','wrap_design','wrap_color','wrap_notes','wrap_fee')) AS i,
                   (SELECT COUNT(*) FROM products WHERE id BETWEEN 7 AND 10) AS p,
                   (SELECT COUNT(*) FROM products WHERE id = 1 AND name = 'White Roses') AS w";
  $s = row($check);
  if ($s['a'] > 0 && $s['k'] > 0 && $s['i'] == 8 && $s['p'] == 4 && $s['w'] > 0) return;
  // Several requests can arrive at the same moment on the very first page load: only one of them may run the setup.
  $lock = row("SELECT GET_LOCK('petalhub_setup', 30) AS l");
  try {
    $s = row($check); // look again now that we hold the lock; another request may have finished the setup already
    if ($s['a'] > 0 && $s['k'] > 0 && $s['i'] == 8 && $s['p'] == 4 && $s['w'] > 0) return;
    $addCol = function($t, $c, $def){
      if (rows('SELECT 1 FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = ? AND COLUMN_NAME = ?', array($t, $c))) return;
      try { q('ALTER TABLE ' . $t . ' ADD COLUMN ' . $c . ' ' . $def); }
      catch (PDOException $e) { if (!isset($e->errorInfo[1]) || $e->errorInfo[1] != 1060) throw $e; } // 1060 = column already exists
    };
    $addCol('products', 'active', 'TINYINT(1) NOT NULL DEFAULT 1');
    $addCol('products', 'description', "VARCHAR(300) NOT NULL DEFAULT ''");
    $addCol('users', 'security_question', 'VARCHAR(120) NULL');
    $addCol('users', 'security_salt', 'CHAR(32) NULL');
    $addCol('users', 'security_hash', 'CHAR(128) NULL');
    $addCol('order_items', 'line_key', 'VARCHAR(60) NULL');
    $addCol('order_items', 'line_name', "VARCHAR(80) NOT NULL DEFAULT ''");
    $addCol('order_items', 'arrangement', "ENUM('single','bouquet','custom') NOT NULL DEFAULT 'single'");
    $addCol('order_items', 'line_qty', 'INT NOT NULL DEFAULT 1');
    $addCol('order_items', 'wrap_design', 'VARCHAR(40) NULL');
    $addCol('order_items', 'wrap_color', "VARCHAR(100) NOT NULL DEFAULT ''");
    $addCol('order_items', 'wrap_notes', "VARCHAR(300) NOT NULL DEFAULT ''");
    $addCol('order_items', 'wrap_fee', 'DECIMAL(10,2) NOT NULL DEFAULT 0');
    // every checkout carries a one-time key; the UNIQUE index makes it impossible to store the same checkout twice
    $addCol('orders', 'checkout_key', 'VARCHAR(60) NULL');
    if (!$s['k']){
      try { q('ALTER TABLE orders ADD UNIQUE KEY uq_orders_user_key (user_id, checkout_key)'); }
      catch (PDOException $e) { if (!isset($e->errorInfo[1]) || $e->errorInfo[1] != 1061) throw $e; } // 1061 = key already exists
    }
    if (!$s['a']){
      try { addUser('Admin', strtolower(ADMIN_EMAIL), ADMIN_PASSWORD, 'admin'); }
      catch (PDOException $e) { if (!isset($e->errorInfo[1]) || $e->errorInfo[1] != 1062) throw $e; } // 1062 = admin already exists
    }
    q("INSERT IGNORE INTO products (id, name, price, qty, unit) VALUES
      (7, 'Red Roses', 32.00, 18, 'bunches available'),
      (8, 'Carnation', 14.00, 26, 'bunches available'),
      (9, 'Chrysanthemum', 18.00, 22, 'bunches available'),
      (10, 'Gladiolus', 20.00, 14, 'bunches available')");
    q("UPDATE products SET name = 'White Roses' WHERE id = 1 AND name = 'Garden Rose'");
  } finally {
    q("SELECT RELEASE_LOCK('petalhub_setup')");
  }
}

/* ---------- login sessions ---------- */
function bearer(){
  if (!empty($_SERVER['HTTP_X_AUTH_TOKEN'])) return $_SERVER['HTTP_X_AUTH_TOKEN'];
  $a = isset($_SERVER['HTTP_AUTHORIZATION']) ? $_SERVER['HTTP_AUTHORIZATION'] : (isset($_SERVER['REDIRECT_HTTP_AUTHORIZATION']) ? $_SERVER['REDIRECT_HTTP_AUTHORIZATION'] : '');
  if ($a === '' && function_exists('getallheaders')) foreach (getallheaders() as $k => $v) if (strtolower($k) === 'authorization') $a = $v;
  return preg_match('/^Bearer (.+)$/', $a, $m) ? $m[1] : '';
}
function authUser(){
  $t = bearer(); if ($t === '') return null;
  return row('SELECT u.id, u.name, u.email, u.role FROM sessions s JOIN users u ON u.id = s.user_id WHERE s.token_hash = ? AND s.expires_at > NOW()', array(hash('sha256', $t)));
}
function startSession($u){
  $t = bin2hex(random_bytes(24));
  q('DELETE FROM sessions WHERE expires_at < NOW()');
  q('INSERT INTO sessions (token_hash, user_id, expires_at) VALUES (?, ?, DATE_ADD(NOW(), INTERVAL 7 DAY))', array(hash('sha256', $t), $u['id']));
  send(200, array('token' => $t, 'user' => array('name' => $u['name'], 'email' => $u['email'], 'role' => $u['role'])));
}
// at most 10 login / register / reset attempts per visitor per 5 minutes
function throttled(){
  $f = sys_get_temp_dir() . '/petalhub_throttle_' . md5(isset($_SERVER['REMOTE_ADDR']) ? $_SERVER['REMOTE_ADDR'] : '0') . '.json';
  $fh = @fopen($f, 'c+'); if (!$fh) return false;
  flock($fh, LOCK_EX);
  $now = time(); $t = array('n' => 0, 'reset' => $now + 300);
  $d = json_decode((string)stream_get_contents($fh), true);
  if (is_array($d) && isset($d['reset']) && $d['reset'] > $now) $t = $d;
  $t['n']++;
  ftruncate($fh, 0); rewind($fh); fwrite($fh, json_encode($t));
  flock($fh, LOCK_UN); fclose($fh);
  return $t['n'] > 10;
}

/* ---------- shaping rows for the website ---------- */
function pub($p){ return array('id' => (int)$p['id'], 'name' => isset($p['name']) ? $p['name'] : '', 'desc' => isset($p['description']) ? $p['description'] : '', 'price' => (float)$p['price'], 'stock' => $p['qty'] . ' ' . $p['unit']); }
function toOrders($rs){
  if (!$rs) return array();
  $codes = array_map(function($r){ return $r['code']; }, $rs);
  $items = rows('SELECT order_code, product_id AS id, name, qty, price, line_key, line_name, arrangement, line_qty, wrap_design, wrap_color, wrap_notes, wrap_fee FROM order_items WHERE order_code IN (' . marks(count($codes)) . ') ORDER BY id', $codes);
  $out = array();
  foreach ($rs as $r){
    $mine = array();
    foreach ($items as $i) if ($i['order_code'] === $r['code']) $mine[] = array(
      'id' => (int)$i['id'], 'name' => $i['name'], 'qty' => (int)$i['qty'], 'price' => (float)$i['price'],
      'lineKey' => $i['line_key'], 'lineName' => $i['line_name'], 'arrangement' => $i['arrangement'],
      'lineQty' => (int)$i['line_qty'], 'wrapDesign' => $i['wrap_design'], 'wrapColor' => $i['wrap_color'],
      'wrapNotes' => $i['wrap_notes'], 'wrapFee' => (float)$i['wrap_fee']);
    $out[] = array('code' => $r['code'], 'date' => iso($r['created_at']), 'customer' => $r['customer'], 'email' => $r['email'], 'total' => (float)$r['total'], 'status' => $r['status'],
      'items' => $mine, 'fulfillment' => $r['fulfillment'], 'address' => array('street' => $r['street'], 'city' => $r['city'], 'zip' => $r['zip']), 'payment' => $r['payment']);
  }
  return $out;
}
function inTx($fn){
  $pdo = db(); $pdo->beginTransaction();
  try { $out = $fn(); $pdo->commit(); return $out; }
  catch (Exception $e) { if ($pdo->inTransaction()) $pdo->rollBack(); throw $e; }
}

/* ---------- the API ---------- */
function handle(){
  $m = $_SERVER['REQUEST_METHOD'];
  $route = '/' . trim(isset($_GET['route']) ? $_GET['route'] : '', '/');
  $FLOW = array('Pending', 'Preparing', 'Ready', 'Completed');
  db(); ensureSetup();

  if ($m === 'GET' && $route === '/products')
    send(200, array_map('pub', rows('SELECT id, name, description, price, qty, unit FROM products WHERE active = 1 ORDER BY id')));
  $me = authUser();
  if ($m === 'GET' && $route === '/me') $me ? send(200, array('user' => array('name' => $me['name'], 'email' => $me['email'], 'role' => $me['role']))) : send(401, array('error' => 'Please log in.'));
  if ($m === 'POST' && $route === '/logout'){ if (bearer() !== '') q('DELETE FROM sessions WHERE token_hash = ?', array(hash('sha256', bearer()))); send(200, emptyObj()); }

  if ($m === 'POST' && ($route === '/register' || $route === '/login')){
    if (throttled()) fail(429, 'Too many attempts. Try again in a few minutes.');
    $b = body(); $email = lower(str(get($b, 'email'), 200)); $pw = is_string(get($b, 'pass')) ? $b['pass'] : '';
    if ($route === '/login'){
      $u = row('SELECT * FROM users WHERE email = ?', array($email));
      if (!$u || !checkHash($u['password_hash'], $pw, $u['salt'])) fail(401, 'Incorrect email or password.');
      if (substr($u['password_hash'], 0, 3) !== 'p2:'){ $s = newSalt(); q('UPDATE users SET salt = ?, password_hash = ? WHERE id = ?', array($s, hashPw($pw, $s), $u['id'])); }
      startSession($u);
    }
    $name = str(get($b, 'name'), 80);
    if ($name === '' || !preg_match('/^\S+@\S+\.\S+$/', $email)) fail(400, 'Enter your name and a valid email.');
    if (strlen($pw) < 6) fail(400, 'Password must be at least 6 characters.');
    if (row('SELECT id FROM users WHERE email = ?', array($email))) fail(409, 'An account with that email already exists. Please log in.');
    $question = str(get($b, 'question'), 120); $answer = str(get($b, 'answer'), 100);
    if (($question !== '' || $answer !== '') && ($question === '' || strlen($answer) < 2)) fail(400, 'Choose a security question and give an answer.');
    $id = addUser($name, $email, $pw, 'customer', $question !== '' ? $question : null, $answer !== '' ? $answer : null);
    startSession(array('id' => $id, 'name' => $name, 'email' => $email, 'role' => 'customer'));
  }

  if ($m === 'GET' && $route === '/orders/mine'){
    if (!$me) fail(401, 'Please log in.');
    send(200, toOrders(rows('SELECT o.*, u.name AS customer, u.email FROM orders o JOIN users u ON u.id = o.user_id WHERE o.user_id = ? ORDER BY o.created_at DESC, o.code DESC', array($me['id']))));
  }

  if ($m === 'POST' && $route === '/forgot'){
    if (throttled()) fail(429, 'Too many attempts. Try again in a few minutes.');
    $email = lower(str(get(body(), 'email'), 200));
    $u = row("SELECT security_question FROM users WHERE email = ? AND role = 'customer'", array($email));
    send(200, array('question' => $u && $u['security_question'] ? $u['security_question'] : null));
  }
  if ($m === 'POST' && $route === '/reset-password'){
    if (throttled()) fail(429, 'Too many attempts. Try again in a few minutes.');
    $b = body(); $email = lower(str(get($b, 'email'), 200)); $pw = is_string(get($b, 'password')) ? $b['password'] : '';
    if (strlen($pw) < 6) fail(400, 'Password must be at least 6 characters.');
    $u = row("SELECT id, security_salt, security_hash FROM users WHERE email = ? AND role = 'customer'", array($email));
    $ans = lower(str(get($b, 'answer'), 100));
    $okAns = $u && $u['security_hash'] && checkHash($u['security_hash'], $ans, (string)$u['security_salt']);
    if (!$okAns) fail(400, 'Incorrect answer.');
    $salt = newSalt();
    q('UPDATE users SET salt = ?, password_hash = ? WHERE id = ?', array($salt, hashPw($pw, $salt), $u['id']));
    q('DELETE FROM sessions WHERE user_id = ?', array($u['id']));
    send(200, emptyObj());
  }

  if ($m === 'POST' && $route === '/orders'){
    if (!$me) fail(401, 'Please log in to place an order.');
    $b = body(); $want = array(); $requested = array(); $lineMap = array(); $its = get($b, 'items');
    if (!is_array($its) || !count($its) || count($its) > 50) fail(400, 'Your cart is empty.');
    $wrapPrices = array('pink-elegance' => 75.00, 'classic-kraft' => 50.00, 'midnight-luxury' => 80.00, 'minimalist-white' => 45.00);
    foreach ($its as $index => $i){
      $id = get($i, 'id'); $n = get($i, 'qty');
      if (!is_numeric($id) || !is_numeric($n) || !isInt($id + 0) || !isInt($n + 0) || $n < 1 || $n > 99) fail(400, 'Invalid cart.');
      $id = (int)$id; $arrangement = get($i, 'arrangement', 'single');
      if (!in_array($arrangement, array('single', 'bouquet', 'custom'), true)) fail(400, 'Invalid arrangement.');
      $lineQty = get($i, 'line_qty', $n);
      if (!is_numeric($lineQty) || !isInt($lineQty + 0) || $lineQty < 1 || $lineQty > 99) fail(400, 'Invalid cart quantity.');
      $lineKey = str(get($i, 'line_key'), 60);
      if ($lineKey === '') $lineKey = 'legacy-' . $index;
      $wrapDesign = str(get($i, 'wrap_design'), 40);
      if ($wrapDesign !== '' && ($arrangement === 'single' || !isset($wrapPrices[$wrapDesign]))) fail(400, 'Invalid wrapping option.');
      $line = array(
        'line_key' => $lineKey,
        'line_name' => str(get($i, 'line_name'), 80),
        'arrangement' => $arrangement,
        'line_qty' => (int)$lineQty,
        'wrap_design' => $wrapDesign === '' ? null : $wrapDesign,
        'wrap_color' => str(get($i, 'wrap_color'), 100),
        'wrap_notes' => str(get($i, 'wrap_notes'), 300)
      );
      if (isset($lineMap[$lineKey]) && $lineMap[$lineKey] !== $line) fail(400, 'Invalid cart grouping.');
      $lineMap[$lineKey] = $line;
      $requested[] = array('id' => $id, 'qty' => (int)$n, 'line' => $line);
      $want[$id] = (isset($want[$id]) ? $want[$id] : 0) + (int)$n;
    }
    $f = get($b, 'fulfillment'); $delivery = $f === 'delivery';
    if (!$delivery && $f !== 'pickup') fail(400, 'Choose pickup or delivery.');
    $a = get($b, 'address', array());
    $ad = $delivery ? array('street' => str(get($a, 'street'), 200), 'city' => str(get($a, 'city'), 100), 'zip' => str(get($a, 'zip'), 20)) : array('street' => '', 'city' => '', 'zip' => '');
    if ($delivery && ($ad['street'] === '' || $ad['city'] === '')) fail(400, 'Enter a delivery address.');
    $payMap = array('card' => 'Credit / debit card', 'wallet' => 'GCash / e-wallet', 'cash' => $delivery ? 'Cash on delivery' : 'Cash on pickup');
    $pk = get($b, 'payment'); $pay = is_string($pk) && isset($payMap[$pk]) ? $payMap[$pk] : null;
    if (!$pay) fail(400, 'Choose a payment method.');
    $key = str(get($b, 'key'), 60); if ($key === '') $key = null;
    $existing = function() use ($me, $key){ return $key ? row('SELECT code FROM orders WHERE user_id = ? AND checkout_key = ?', array($me['id'], $key)) : null; };
    try {
      $out = inTx(function() use ($want, $requested, $lineMap, $wrapPrices, $existing, $me, $f, $ad, $pay, $key){
        $ids = array_keys($want); sort($ids);
        $prods = rows('SELECT id, name, price, qty FROM products WHERE id IN (' . marks(count($ids)) . ') AND active = 1 ORDER BY id FOR UPDATE', $ids);
        $dup = $existing(); // checked again after the product lock, so two simultaneous requests cannot both pass
        if ($dup) return array('code' => $dup['code'], 'duplicate' => true);
        if (count($prods) !== count($ids)) fail(400, 'Unknown product.');
        $total = 0;
        foreach ($prods as $p){
          if ($want[(int)$p['id']] > $p['qty']) fail(409, $p['qty'] ? 'Only ' . $p['qty'] . ' left of ' . $p['name'] . '.' : $p['name'] . ' is out of stock.');
          $total += (float)$p['price'] * $want[(int)$p['id']];
        }
        foreach ($lineMap as $line) if ($line['wrap_design']) $total += $wrapPrices[$line['wrap_design']] * $line['line_qty'];
        $total = round($total, 2);
        do { $oc = 'PH-' . random_int(100000, 999999); } while (row('SELECT 1 FROM orders WHERE code = ?', array($oc)));
        q('INSERT INTO orders (code, user_id, total, fulfillment, street, city, zip, payment, checkout_key) VALUES (?,?,?,?,?,?,?,?,?)',
          array($oc, $me['id'], $total, $f, $ad['street'], $ad['city'], $ad['zip'], $pay, $key));
        $productsById = array();
        foreach ($prods as $p) $productsById[(int)$p['id']] = $p;
        $feesApplied = array();
        foreach ($requested as $item){
          $p = $productsById[$item['id']]; $line = $item['line'];
          $fee = 0;
          if (!isset($feesApplied[$line['line_key']]) && $line['wrap_design']){
            $fee = $wrapPrices[$line['wrap_design']] * $line['line_qty'];
            $feesApplied[$line['line_key']] = true;
          }
          $lineName = $line['line_name'] !== '' ? $line['line_name'] : $p['name'];
          q('INSERT INTO order_items (order_code, product_id, name, qty, price, line_key, line_name, arrangement, line_qty, wrap_design, wrap_color, wrap_notes, wrap_fee) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)',
            array($oc, $p['id'], $p['name'], $item['qty'], $p['price'], $line['line_key'], $lineName, $line['arrangement'], $line['line_qty'], $line['wrap_design'], $line['wrap_color'], $line['wrap_notes'], $fee));
        }
        foreach ($prods as $p){
          q('UPDATE products SET qty = qty - ? WHERE id = ?', array($want[(int)$p['id']], $p['id']));
        }
        return array('code' => $oc);
      });
    } catch (PDOException $e) {
      if (isset($e->errorInfo[1]) && $e->errorInfo[1] == 1062 && $key && ($dup = $existing())) $out = array('code' => $dup['code'], 'duplicate' => true);
      else throw $e;
    }
    send(!empty($out['duplicate']) ? 200 : 201, $out);
  }

  if (strpos($route, '/admin/') === 0){
    if (!$me || $me['role'] !== 'admin') fail(403, 'Admin access only.');
    if ($m === 'GET' && $route === '/admin/orders')
      send(200, toOrders(rows('SELECT o.*, u.name AS customer, u.email FROM orders o JOIN users u ON u.id = o.user_id ORDER BY o.created_at DESC, o.code DESC')));
    if ($m === 'GET' && $route === '/admin/customers') send(200, rows("SELECT name, email FROM users WHERE role = 'customer' ORDER BY id"));
    if ($m === 'PATCH' && preg_match('#^/admin/orders/(PH-\d+)$#', $route, $r)){
      $s = get(body(), 'status'); $code = $r[1];
      $out = inTx(function() use ($s, $code, $FLOW){
        $o = row('SELECT status FROM orders WHERE code = ? FOR UPDATE', array($code));
        if (!$o) fail(404, 'Order not found.');
        $i = array_search($o['status'], $FLOW, true);
        if ($s === 'Cancelled' && $i !== false && $i < count($FLOW) - 1){
          foreach (rows('SELECT product_id, qty FROM order_items WHERE order_code = ?', array($code)) as $it) q('UPDATE products SET qty = qty + ? WHERE id = ?', array($it['qty'], $it['product_id']));
        } elseif (!($i !== false && isset($FLOW[$i + 1]) && $s === $FLOW[$i + 1])) fail(400, "That status change isn't allowed.");
        q('UPDATE orders SET status = ? WHERE code = ?', array($s, $code));
        return array('code' => $code, 'status' => $s);
      });
      send(200, $out);
    }
    if ($m === 'POST' && $route === '/admin/products'){
      $b = body(); $name = str(get($b, 'name'), 80); $price = get($b, 'price'); $qty = get($b, 'qty');
      if ($name === '' || !isNum($price) || !($price >= 0 && $price <= 1e5) || !isInt($qty) || $qty < 0 || $qty > 1e5) fail(400, 'Enter a name, a valid price and a quantity.');
      $id = (int)row('SELECT COALESCE(MAX(id), 0) + 1 AS n FROM products')['n'];
      q('INSERT INTO products (id, name, price, qty, unit, description) VALUES (?,?,?,?,?,?)', array($id, $name, $price, (int)$qty, 'bunches available', str(get($b, 'desc'), 300)));
      send(201, array('id' => $id));
    }
    if (preg_match('#^/admin/products/(\d+)$#', $route, $r)){
      $id = (int)$r[1];
      if ($m === 'DELETE'){ q('UPDATE products SET active = 0 WHERE id = ?', array($id)); send(200, emptyObj()); }
      if ($m === 'PUT'){
        $b = body(); $price = get($b, 'price'); $qty = get($b, 'qty');
        if (!isNum($price) || !($price >= 0 && $price <= 1e5) || !isInt($qty) || $qty < 0 || $qty > 1e5) fail(400, 'Enter a valid price and quantity.');
        if (!row('SELECT id FROM products WHERE id = ?', array($id))) fail(404, 'Product not found.');
        q('UPDATE products SET price = ?, qty = ? WHERE id = ?', array($price, (int)$qty, $id));
        send(200, pub(row('SELECT id, price, qty, unit FROM products WHERE id = ?', array($id))));
      }
    }
  }
  fail(404, 'Not found.');
}

try { handle(); }
catch (ApiError $e) { send($e->getCode() ?: 500, array('error' => $e->getMessage())); }
catch (Throwable $e) {
  error_log('PetalHub: ' . $e->getMessage() . ' (' . basename($e->getFile()) . ':' . $e->getLine() . ')');
  // PH_DEBUG (config.php) shows the real reason on screen, which makes problems easy to report. Set it to false when you are done.
  $detail = (!defined('PH_DEBUG') || PH_DEBUG) ? ' ' . $e->getMessage() . ' [' . basename($e->getFile()) . ':' . $e->getLine() . ']' : '';
  send(500, array('error' => 'Server error.' . $detail));
}
